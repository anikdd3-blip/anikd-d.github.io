import { AlertTriangle, CheckCircle2, CircleSlash, MinusCircle, ShieldAlert } from "lucide-react";

import { ACCEPT_THRESHOLD, type CheckResult, type ProblemRegion } from "@/lib/id-rules";

export function ScoreDial({
  score,
  status,
}: {
  score: number;
  status: "ACCEPTED" | "REJECTED";
}) {
  const accepted = status === "ACCEPTED";
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.max(0, Math.min(100, score)) / 100);

  return (
    <div className="flex items-center gap-5">
      <div className="relative size-32 shrink-0">
        <svg viewBox="0 0 120 120" className="size-32 -rotate-90">
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            strokeWidth="10"
            className="stroke-border"
          />
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className={accepted ? "stroke-success" : "stroke-destructive"}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-mono text-2xl font-semibold">{score.toFixed(1)}%</span>
          <span className="label-caps mt-0.5">Authenticity</span>
        </div>
      </div>
      <div>
        <span
          className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-sm font-semibold ${
            accepted
              ? "bg-success/15 text-success"
              : "bg-destructive/15 text-destructive"
          }`}
        >
          {accepted ? (
            <CheckCircle2 className="size-4" aria-hidden="true" />
          ) : (
            <ShieldAlert className="size-4" aria-hidden="true" />
          )}
          {accepted ? "Accepted" : "Rejected"}
        </span>
        <p className="mt-2 max-w-xs text-sm text-muted-foreground">
          {accepted
            ? `Score is above the ${ACCEPT_THRESHOLD}% acceptance threshold. The document and the person were both verified.`
            : `Score is below the ${ACCEPT_THRESHOLD}% acceptance threshold, so the document was not accepted.`}
        </p>
      </div>
    </div>
  );
}

const statusIcon = {
  pass: <CheckCircle2 className="size-4 text-success" aria-hidden="true" />,
  warn: <AlertTriangle className="size-4 text-warning" aria-hidden="true" />,
  fail: <CircleSlash className="size-4 text-destructive" aria-hidden="true" />,
  skipped: <MinusCircle className="size-4 text-muted-foreground" aria-hidden="true" />,
};

export function ChecksList({ checks }: { checks: CheckResult[] }) {
  return (
    <ul className="divide-y divide-border">
      {checks.map((c) => (
        <li key={c.key} className="flex gap-3 py-3">
          <span className="mt-0.5">{statusIcon[c.status]}</span>
          <div className="min-w-0">
            <p className="text-sm font-medium">{c.label}</p>
            <p className="mt-0.5 text-sm text-muted-foreground">{c.detail}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}

export function AnnotatedCard({
  image,
  regions,
}: {
  image: string;
  regions: ProblemRegion[];
}) {
  return (
    <div className="relative overflow-hidden rounded-lg border border-border">
      <img src={image} alt="Submitted identity document with problem areas marked" className="w-full" />
      {regions.map((r, i) => {
        const tone =
          r.severity === "high"
            ? "border-destructive text-destructive-foreground bg-destructive/20"
            : r.severity === "medium"
              ? "border-warning text-warning-foreground bg-warning/20"
              : "border-primary text-primary-foreground bg-primary/20";
        return (
          <div
            key={`${r.label}-${i}`}
            className={`absolute rounded-sm border-2 ${tone}`}
            style={{
              left: `${Math.max(0, Math.min(1, r.region.x)) * 100}%`,
              top: `${Math.max(0, Math.min(1, r.region.y)) * 100}%`,
              width: `${Math.max(0.02, Math.min(1, r.region.w)) * 100}%`,
              height: `${Math.max(0.02, Math.min(1, r.region.h)) * 100}%`,
            }}
            title={r.detail}
          >
            <span className="absolute -top-6 left-0 whitespace-nowrap rounded bg-background/90 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-foreground">
              {i + 1}. {r.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}
