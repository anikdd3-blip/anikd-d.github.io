import { Camera, ImageUp, RefreshCw } from "lucide-react";
import { useRef } from "react";

type Props = {
  title: string;
  hint: string;
  value: string | null;
  onPick: (dataUrl: string) => void;
  capture?: "user" | "environment";
};

export async function fileToDataUrl(file: File, maxSize = 1500): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read that image."));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error("Could not open that image."));
    el.src = dataUrl;
  });

  const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(img.width * scale);
  canvas.height = Math.round(img.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.9);
}

export function UploadTile({ title, hint, value, onPick, capture }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);

  const handle = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    onPick(await fileToDataUrl(file));
  };

  return (
    <div className="panel overflow-hidden">
      <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
        <div>
          <p className="label-caps">{title}</p>
          <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
        </div>
        {value && (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-1.5 rounded-md border border-border bg-secondary px-2.5 py-1.5 text-xs font-medium text-secondary-foreground transition-colors hover:bg-accent"
          >
            <RefreshCw className="size-3.5" aria-hidden="true" /> Replace
          </button>
        )}
      </div>

      <button
        type="button"
        onClick={() => fileRef.current?.click()}
        className="group relative block w-full cursor-pointer"
        aria-label={`Upload ${title}`}
      >
        {value ? (
          <img src={value} alt={title} className="aspect-[4/3] w-full object-cover" />
        ) : (
          <span className="flex aspect-[4/3] w-full flex-col items-center justify-center gap-3 bg-background/40 text-muted-foreground transition-colors group-hover:bg-accent/40">
            <ImageUp className="size-8" aria-hidden="true" />
            <span className="text-sm font-medium">Tap to upload a photo</span>
            <span className="text-xs">JPG or PNG</span>
          </span>
        )}
      </button>

      <div className="grid grid-cols-2 gap-2 border-t border-border p-3">
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="inline-flex items-center justify-center gap-2 rounded-md bg-secondary px-3 py-2 text-xs font-medium text-secondary-foreground transition-colors hover:bg-accent"
        >
          <ImageUp className="size-4" aria-hidden="true" /> Upload photo
        </button>
        <button
          type="button"
          onClick={() => cameraRef.current?.click()}
          className="inline-flex items-center justify-center gap-2 rounded-md border border-border px-3 py-2 text-xs font-medium transition-colors hover:bg-accent"
        >
          <Camera className="size-4" aria-hidden="true" /> Take photo
        </button>
      </div>

      <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handle} />
      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture={capture ?? "environment"}
        className="hidden"
        onChange={handle}
      />
    </div>
  );
}
