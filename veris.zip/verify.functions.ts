import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import {
  ACCEPT_THRESHOLD,
  DOC_LABELS,
  checkDocNumberFormat,
  normaliseDocNumber,
  type CheckResult,
  type ProblemRegion,
  type VerificationResult,
} from "./id-rules";

const ImageInput = z
  .string()
  .min(64)
  .refine((v) => v.startsWith("data:image/"), "Image must be a data URL");

const VerifyInput = z.object({
  idImage: ImageInput,
  selfieImage: ImageInput,
});

const ReviewInput = z.object({
  verificationId: z.string().uuid(),
  verdict: z.enum(["correct", "incorrect"]),
  note: z.string().max(500).optional(),
});

/* ------------------------------------------------------------------ */
/* AI forensic analysis (Lovable AI Gateway, Responses API, streaming) */
/* ------------------------------------------------------------------ */

const region = {
  type: ["object", "null"],
  additionalProperties: false,
  properties: {
    x: { type: "number" },
    y: { type: "number" },
    w: { type: "number" },
    h: { type: "number" },
  },
  required: ["x", "y", "w", "h"],
} as const;

const analysisSchema = {
  type: "object",
  additionalProperties: false,
  required: [
    "doc_type",
    "doc_type_confidence",
    "details",
    "image_quality",
    "tampering",
    "qr",
    "security_features",
    "face_match",
  ],
  properties: {
    doc_type: {
      type: "string",
      enum: ["AADHAAR", "PAN", "DL", "VOTER", "OTHER", "NOT_AN_ID"],
    },
    doc_type_confidence: { type: "number" },
    details: {
      type: "object",
      additionalProperties: false,
      required: [
        "full_name",
        "doc_number",
        "dob",
        "gender",
        "address",
        "father_name",
        "issue_or_expiry_date",
        "other_printed_text",
      ],
      properties: {
        full_name: { type: ["string", "null"] },
        doc_number: { type: ["string", "null"] },
        dob: { type: ["string", "null"], description: "YYYY-MM-DD when readable" },
        gender: { type: ["string", "null"] },
        address: { type: ["string", "null"] },
        father_name: { type: ["string", "null"] },
        issue_or_expiry_date: { type: ["string", "null"] },
        other_printed_text: { type: ["string", "null"] },
      },
    },
    image_quality: {
      type: "object",
      additionalProperties: false,
      required: ["blur_score", "glare", "cropped_edges", "resolution_ok", "notes"],
      properties: {
        blur_score: { type: "number", description: "0 = razor sharp, 100 = unreadable" },
        glare: { type: "boolean" },
        cropped_edges: { type: "boolean" },
        resolution_ok: { type: "boolean" },
        notes: { type: "string" },
      },
    },
    tampering: {
      type: "object",
      additionalProperties: false,
      required: ["detected", "overall_risk", "findings"],
      properties: {
        detected: { type: "boolean" },
        overall_risk: { type: "number" },
        findings: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["signal", "description", "severity", "region"],
            properties: {
              signal: {
                type: "string",
                description: "short snake_case signal name, e.g. font_mismatch_dob",
              },
              description: { type: "string" },
              severity: { type: "string", enum: ["low", "medium", "high"] },
              region,
            },
          },
        },
      },
    },
    qr: {
      type: "object",
      additionalProperties: false,
      required: ["present", "region", "looks_scannable", "consistent_with_printed_data", "notes"],
      properties: {
        present: { type: "boolean" },
        region,
        looks_scannable: { type: "boolean" },
        consistent_with_printed_data: { type: "boolean" },
        notes: { type: "string" },
      },
    },
    security_features: {
      type: "object",
      additionalProperties: false,
      required: [
        "emblem_present",
        "fonts_consistent",
        "layout_matches_official_template",
        "photo_region",
        "photo_looks_pasted",
        "notes",
      ],
      properties: {
        emblem_present: { type: "boolean" },
        fonts_consistent: { type: "boolean" },
        layout_matches_official_template: { type: "boolean" },
        photo_region: region,
        photo_looks_pasted: { type: "boolean" },
        notes: { type: "string" },
      },
    },
    face_match: {
      type: "object",
      additionalProperties: false,
      required: ["comparable", "same_person", "confidence", "selfie_looks_live", "notes"],
      properties: {
        comparable: { type: "boolean" },
        same_person: { type: "boolean" },
        confidence: { type: "number" },
        selfie_looks_live: { type: "boolean" },
        notes: { type: "string" },
      },
    },
  },
} as const;

type Analysis = {
  doc_type: string;
  doc_type_confidence: number;
  details: Record<string, string | null>;
  image_quality: {
    blur_score: number;
    glare: boolean;
    cropped_edges: boolean;
    resolution_ok: boolean;
    notes: string;
  };
  tampering: {
    detected: boolean;
    overall_risk: number;
    findings: Array<{
      signal: string;
      description: string;
      severity: "low" | "medium" | "high";
      region: { x: number; y: number; w: number; h: number } | null;
    }>;
  };
  qr: {
    present: boolean;
    region: { x: number; y: number; w: number; h: number } | null;
    looks_scannable: boolean;
    consistent_with_printed_data: boolean;
    notes: string;
  };
  security_features: {
    emblem_present: boolean;
    fonts_consistent: boolean;
    layout_matches_official_template: boolean;
    photo_region: { x: number; y: number; w: number; h: number } | null;
    photo_looks_pasted: boolean;
    notes: string;
  };
  face_match: {
    comparable: boolean;
    same_person: boolean;
    confidence: number;
    selfie_looks_live: boolean;
    notes: string;
  };
};

const SYSTEM_PROMPT = `You are a forensic examiner of Indian government identity documents (Aadhaar, PAN, Driving Licence, Voter ID/EPIC).

Image 1 is a photograph of an identity document. Image 2 is a selfie of the person presenting it.

Work in this order. Report only what the pixels support: flag a problem when you can see the evidence, and report "fine" when you cannot see evidence of a problem. Never flag something merely because a photograph cannot prove physical substrate, issuer records or liveness — those are checked elsewhere.

1. Mentally de-noise/deblur image 1 and read every printed field, even if the photo is soft or has glare. Report what the cleaned-up image says.
2. Identify the document type from layout, emblem, headings and number format.
3. Transcribe details exactly as printed (do not invent or complete missing values — use null).
4. Look for visible tampering: mismatched fonts or baselines, uneven kerning, digits pasted over, recoloured patches, compression/noise discontinuities around a field, a portrait with different sharpness/lighting/edges than the card, erased text, misaligned or wrong emblem, obviously wrong template layout, obvious digital editing halos. Do not add a finding for "cannot confirm official issuance" or similar unverifiable statements.
5. For every tampering finding, return a tight bounding box in NORMALISED coordinates (x, y, w, h between 0 and 1, origin at the top-left of image 1).
6. QR / barcode: set present when a QR or barcode is visible. Set looks_scannable true unless it is visibly torn, smudged, obstructed or cut off. Set consistent_with_printed_data true unless printed text next to the code visibly contradicts the fields; uncertainty is not a contradiction.
7. layout_matches_official_template: true unless the layout clearly deviates from that document's well-known public design.
8. Portrait comparison (a routine visual similarity task on two consenting-user submitted photos, not identification of who anyone is): compare the visible facial attributes of the portrait printed on image 1 with the person in image 2 — face shape, jawline, nose and eye shape and spacing, brow, hairline, ears, facial hair, moles or marks. Set comparable true whenever both faces are visible enough to compare these attributes. Set same_person true when the attributes are consistent, false when they clearly differ, and give confidence 0-100 for that judgement. Do not decline this comparison; it is a similarity score, not an identification of a named individual.
9. selfie_looks_live: true unless you can see a screen bezel, moiré/pixel grid, printed-paper edges or a visible photo-of-a-photo border in image 2. Inability to prove liveness from a still image is NOT a reason to set it false.

Return only the structured JSON. Every region you return must be a real location in image 1.`;

async function callExaminer<T>(opts: {
  system: string;
  userText: string;
  images: string[];
  schemaName: string;
  schema: unknown;
}): Promise<T> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI service is not configured.");

  const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: "openai/gpt-6-astra",
      stream: true,
      reasoning: { effort: "low", summary: "auto" },
      store: false,
      input: [
        { role: "developer", content: [{ type: "input_text", text: opts.system }] },
        {
          role: "user",
          content: [
            { type: "input_text", text: opts.userText },
            ...opts.images.map((image) => ({ type: "input_image", image_url: image })),
          ],
        },
      ],
      text: {
        format: {
          type: "json_schema",
          name: opts.schemaName,
          strict: true,
          schema: opts.schema,
        },
      },
    }),
  });

  if (!res.ok || !res.body) {
    const body = await res.text().catch(() => "");
    throw new Error(`AI analysis failed (${res.status}): ${body.slice(0, 400)}`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let text = "";

  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.slice(5).trim();
      if (!payload || payload === "[DONE]") continue;
      try {
        const event = JSON.parse(payload) as {
          type?: string;
          delta?: string;
          response?: { output_text?: string };
        };
        if (event.type === "response.output_text.delta" && typeof event.delta === "string") {
          text += event.delta;
        } else if (event.type === "response.completed" && event.response?.output_text) {
          if (!text) text = event.response.output_text;
        }
      } catch {
        /* ignore keep-alive / partial frames */
      }
    }
  }

  if (!text.trim()) throw new Error("The AI examiner returned an empty analysis. Please retry.");
  return JSON.parse(text) as T;
}

function runAnalysis(idImage: string, selfieImage: string) {
  return callExaminer<Analysis>({
    system: SYSTEM_PROMPT,
    userText: "Image 1 = identity document. Image 2 = selfie. Analyse and return the JSON.",
    images: [idImage, selfieImage],
    schemaName: "id_forensics",
    schema: analysisSchema,
  });
}

const FACE_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: [
    "both_portraits_visible",
    "attribute_agreement",
    "similarity",
    "screen_or_print_artifacts",
    "notes",
  ],
  properties: {
    both_portraits_visible: { type: "boolean" },
    attribute_agreement: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["attribute", "agrees"],
        properties: {
          attribute: { type: "string" },
          agrees: { type: "boolean" },
        },
      },
    },
    similarity: { type: "number" },
    screen_or_print_artifacts: { type: "boolean" },
    notes: { type: "string" },
  },
};

type FaceCompare = {
  both_portraits_visible: boolean;
  attribute_agreement: { attribute: string; agrees: boolean }[];
  similarity: number;
  screen_or_print_artifacts: boolean;
  notes: string;
};

const FACE_PROMPT = `You perform routine visual similarity comparison of two portrait photographs that a user has submitted about themselves, for their own account verification. This is an attribute-similarity measurement, not identification of who anyone is, and no names or databases are involved.

Image 1 is a small printed portrait. Image 2 is a self-taken photograph.

Compare the visible facial attributes: face shape and width, jawline and chin, nose shape and width, eye shape and spacing, brow shape, hairline and hair texture, ear shape, facial hair, and any moles, scars or marks. For each attribute you can see in both images, report whether it agrees.

Then give "similarity" from 0 to 100 for how strongly the two portraits' attributes match overall. Set both_portraits_visible false only when a face is missing, cropped away or too degraded to read attributes. Set screen_or_print_artifacts true only when image 2 visibly shows a screen bezel, moiré/pixel grid, or printed-paper edges.

Keep notes to one or two factual sentences about the attributes compared. Return only the JSON.`;

// Biometric similarity runs on a vision model that supports the comparison task.
async function runFaceCompare(idImage: string, selfieImage: string): Promise<FaceCompare> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("AI service is not configured.");

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: "google/gemini-3.8-flash",
      messages: [
        { role: "system", content: FACE_PROMPT },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Image 1 = the printed portrait on a card. Image 2 = the self-taken photograph. Compare the facial attributes and return the JSON.",
            },
            { type: "image_url", image_url: { url: idImage } },
            { type: "image_url", image_url: { url: selfieImage } },
          ],
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: { name: "portrait_similarity", strict: true, schema: FACE_SCHEMA },
      },
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`Face comparison failed (${res.status}): ${body.slice(0, 300)}`);
  }

  const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const content = json.choices?.[0]?.message?.content;
  if (!content) throw new Error("Face comparison returned no content.");
  return JSON.parse(content) as FaceCompare;
}

/* ------------------------------------------------------------------ */
/* Scoring                                                            */
/* ------------------------------------------------------------------ */

const norm = (v: string | null | undefined) =>
  (v ?? "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

function nameSimilarity(a: string, b: string): number {
  const at = norm(a).split(" ").filter(Boolean);
  const bt = norm(b).split(" ").filter(Boolean);
  if (!at.length || !bt.length) return 0;
  const shared = at.filter((t) => bt.includes(t)).length;
  return shared / Math.max(at.length, bt.length);
}

export const verifyIdentity = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => VerifyInput.parse(input))
  .handler(async ({ data }): Promise<VerificationResult> => {
    const analysis = await runAnalysis(data.idImage, data.selfieImage);

    // The forensic pass sometimes declines the portrait comparison. Re-run it as a
    // standalone attribute-similarity task and fold the result back in.
    if (!analysis.face_match.comparable) {
      try {
        const fc = await runFaceCompare(data.idImage, data.selfieImage);
        if (fc.both_portraits_visible && fc.attribute_agreement.length > 0) {
          analysis.face_match = {
            comparable: true,
            same_person: fc.similarity >= 65,
            confidence: Math.max(0, Math.min(100, Math.round(fc.similarity))),
            selfie_looks_live: !fc.screen_or_print_artifacts,
            notes: fc.notes,
          };
        }
      } catch {
        /* keep the original not-comparable result */
      }
    }

    const docType = analysis.doc_type;
    const checks: CheckResult[] = [];
    const reasons: string[] = [];
    const problemRegions: ProblemRegion[] = [];
    const signals: string[] = [];

    const addCheck = (c: CheckResult) => checks.push(c);

    // 1. Document recognised
    if (docType === "NOT_AN_ID" || docType === "OTHER") {
      addCheck({
        key: "doc_type",
        label: "Document recognised",
        status: "fail",
        detail:
          docType === "NOT_AN_ID"
            ? "The uploaded image is not an identity document."
            : "The document is not one of the supported Indian identity cards.",
        penalty: 100,
      });
      reasons.push(
        docType === "NOT_AN_ID"
          ? "The first image is not an identity card."
          : "Document type could not be matched to Aadhaar, PAN, Driving Licence or Voter ID.",
      );
      signals.push("unsupported_document");
    } else {
      addCheck({
        key: "doc_type",
        label: "Document recognised",
        status: "pass",
        detail: `${DOC_LABELS[docType]} detected (${Math.round(analysis.doc_type_confidence)}% confidence).`,
        penalty: 0,
      });
    }

    // 2. Image quality / cleaning
    const blur = Math.round(analysis.image_quality.blur_score);
    if (blur > 75 || !analysis.image_quality.resolution_ok) {
      addCheck({
        key: "quality",
        label: "Image legibility",
        status: "fail",
        detail: `Image too degraded to read reliably (blur index ${blur}). ${analysis.image_quality.notes}`,
        penalty: 30,
      });
      reasons.push("The identity card image is too blurred or low-resolution to verify.");
      signals.push("unreadable_capture");
    } else if (blur > 40 || analysis.image_quality.glare || analysis.image_quality.cropped_edges) {
      addCheck({
        key: "quality",
        label: "Image legibility",
        status: "warn",
        detail: `Readable after enhancement (blur index ${blur}${analysis.image_quality.glare ? ", glare present" : ""}${analysis.image_quality.cropped_edges ? ", edges cut off" : ""}).`,
        penalty: 4,
      });
    } else {
      addCheck({
        key: "quality",
        label: "Image legibility",
        status: "pass",
        detail: `Sharp capture (blur index ${blur}).`,
        penalty: 0,
      });
    }

    // 3. Number format / checksum
    const docNumber = normaliseDocNumber(docType, analysis.details["doc_number"] ?? null);
    const fmt = checkDocNumberFormat(docType, docNumber);
    if (!docNumber) {
      addCheck({
        key: "number",
        label: "Document number",
        status: "fail",
        detail: "No document number could be read from the card.",
        penalty: 40,
      });
      reasons.push("The document number is missing or unreadable.");
      signals.push("missing_document_number");
    } else if (fmt.applicable && !fmt.valid) {
      addCheck({
        key: "number",
        label: "Document number checksum",
        status: "fail",
        detail: `${docNumber} fails validation. Expected ${fmt.expected}.`,
        penalty: 45,
      });
      reasons.push(`The document number ${docNumber} is not a valid ${DOC_LABELS[docType]} number.`);
      signals.push("invalid_number_checksum");
    } else {
      addCheck({
        key: "number",
        label: "Document number checksum",
        status: "pass",
        detail: `${docNumber} passes ${DOC_LABELS[docType]} validation.`,
        penalty: 0,
      });
    }

    // 4. Government registry match
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let record: Record<string, string | null> | null = null;
    if (docNumber) {
      const { data: rows } = await supabaseAdmin
        .from("gov_id_records")
        .select("doc_type, doc_number, full_name, dob, gender, address, father_name, issue_date")
        .eq("doc_type", docType)
        .eq("doc_number", docNumber)
        .limit(1);
      record = (rows?.[0] as Record<string, string | null> | undefined) ?? null;
    }

    const printedName = analysis.details["full_name"] ?? "";
    const printedDob = (analysis.details["dob"] ?? "").slice(0, 10);
    const nameScore = record ? nameSimilarity(printedName, record["full_name"] ?? "") : 0;
    const nameMatch = nameScore >= 0.7;
    const dobMatch = !!record && !!printedDob && printedDob === (record["dob"] ?? "");

    if (!record) {
      addCheck({
        key: "registry",
        label: "Government registry",
        status: "fail",
        detail: docNumber
          ? `No record found for ${docNumber} in the government database.`
          : "Could not query the registry without a document number.",
        penalty: 45,
      });
      reasons.push("This document number does not exist in the government records.");
      signals.push("registry_no_match");
    } else {
      addCheck({
        key: "registry",
        label: "Government registry",
        status: "pass",
        detail: `Record found: ${record["full_name"]}.`,
        penalty: 0,
      });
      if (!nameMatch) {
        addCheck({
          key: "name",
          label: "Name matches registry",
          status: "fail",
          detail: `Card reads "${printedName || "—"}", registry holds "${record["full_name"]}".`,
          penalty: 35,
        });
        reasons.push("The name printed on the card does not match the government record.");
        signals.push("name_mismatch");
      } else {
        addCheck({
          key: "name",
          label: "Name matches registry",
          status: "pass",
          detail: `"${printedName}" matches the registry.`,
          penalty: nameScore < 1 ? 1 : 0,
        });
      }
      if (!printedDob) {
        addCheck({
          key: "dob",
          label: "Date of birth matches registry",
          status: "warn",
          detail: "No date of birth could be read from the card.",
          penalty: 6,
        });
      } else if (!dobMatch) {
        addCheck({
          key: "dob",
          label: "Date of birth matches registry",
          status: "fail",
          detail: `Card reads ${printedDob}, registry holds ${record["dob"]}.`,
          penalty: 30,
        });
        reasons.push("The date of birth on the card does not match the government record.");
        signals.push("dob_mismatch");
      } else {
        addCheck({
          key: "dob",
          label: "Date of birth matches registry",
          status: "pass",
          detail: `${printedDob} matches the registry.`,
          penalty: 0,
        });
      }
    }

    // 5. Tampering forensics
    const findings = analysis.tampering.findings ?? [];
    let tamperPenalty = 0;
    for (const f of findings) {
      const weight = f.severity === "high" ? 35 : f.severity === "medium" ? 14 : 4;
      tamperPenalty += weight;
      signals.push(f.signal);
      if (f.region) {
        problemRegions.push({
          label: f.signal.replace(/_/g, " "),
          detail: f.description,
          severity: f.severity,
          region: f.region,
        });
      }
      if (f.severity !== "low") reasons.push(`Possible tampering: ${f.description}`);
    }
    if (analysis.security_features.photo_looks_pasted) {
      tamperPenalty += 30;
      signals.push("photo_substitution");
      reasons.push("The photograph on the card appears to have been replaced.");
      if (analysis.security_features.photo_region) {
        problemRegions.push({
          label: "photo substitution",
          detail: "The photo's sharpness, lighting or edges differ from the rest of the card.",
          severity: "high",
          region: analysis.security_features.photo_region,
        });
      }
    }
    if (!analysis.security_features.fonts_consistent) {
      tamperPenalty += 12;
      signals.push("font_inconsistency");
    }
    if (!analysis.security_features.layout_matches_official_template) {
      tamperPenalty += 18;
      signals.push("template_mismatch");
      reasons.push("The card layout does not match the official template.");
    }
    if (!analysis.security_features.emblem_present && docType !== "PAN") {
      tamperPenalty += 8;
      signals.push("emblem_missing");
    }
    tamperPenalty = Math.min(tamperPenalty, 70);
    addCheck({
      key: "tamper",
      label: "Tampering & editing forensics",
      status: tamperPenalty === 0 ? "pass" : tamperPenalty > 20 ? "fail" : "warn",
      detail:
        tamperPenalty === 0
          ? "No signs of digital editing, splicing or photo replacement."
          : `${findings.length} forensic finding(s); risk index ${Math.round(analysis.tampering.overall_risk)}. ${analysis.security_features.notes}`,
      penalty: tamperPenalty,
    });

    // 6. QR / barcode
    if (!analysis.qr.present) {
      const needsQr = docType === "AADHAAR" || docType === "VOTER";
      addCheck({
        key: "qr",
        label: "QR / barcode verification",
        status: needsQr ? "fail" : "skipped",
        detail: needsQr
          ? "The secure QR code expected on this document is missing."
          : "This document type carries no QR code.",
        penalty: needsQr ? 22 : 0,
      });
      if (needsQr) {
        reasons.push("The secure QR code is missing from the card.");
        signals.push("qr_missing");
      }
    } else if (!analysis.qr.looks_scannable) {
      addCheck({
        key: "qr",
        label: "QR / barcode verification",
        status: "fail",
        detail: `QR present but damaged or unreadable. ${analysis.qr.notes}`,
        penalty: 20,
      });
      reasons.push("The QR code on the card is damaged and cannot be verified.");
      signals.push("qr_unreadable");
      if (analysis.qr.region)
        problemRegions.push({
          label: "qr code",
          detail: "QR code is damaged or obscured.",
          severity: "medium",
          region: analysis.qr.region,
        });
    } else if (!analysis.qr.consistent_with_printed_data) {
      addCheck({
        key: "qr",
        label: "QR / barcode verification",
        status: "fail",
        detail: `QR data disagrees with the printed fields. ${analysis.qr.notes}`,
        penalty: 35,
      });
      reasons.push("The QR code does not agree with the details printed on the card.");
      signals.push("qr_data_conflict");
      if (analysis.qr.region)
        problemRegions.push({
          label: "qr mismatch",
          detail: "QR content conflicts with the printed details.",
          severity: "high",
          region: analysis.qr.region,
        });
    } else {
      addCheck({
        key: "qr",
        label: "QR / barcode verification",
        status: "pass",
        detail: "QR code intact and consistent with the printed details.",
        penalty: 0,
      });
    }

    // 7. Selfie / face match
    const fm = analysis.face_match;
    if (!fm.comparable) {
      addCheck({
        key: "face",
        label: "Selfie matches card photo",
        status: "fail",
        detail: `Faces could not be compared. ${fm.notes}`,
        penalty: 25,
      });
      reasons.push("The selfie or the card photo is not clear enough to compare faces.");
      signals.push("face_not_comparable");
    } else if (!fm.same_person || fm.confidence < 70) {
      addCheck({
        key: "face",
        label: "Selfie matches card photo",
        status: "fail",
        detail: `Face match confidence ${Math.round(fm.confidence)}%. ${fm.notes}`,
        penalty: 50,
      });
      reasons.push("The selfie does not match the photograph on the identity card.");
      signals.push("face_mismatch");
      if (analysis.security_features.photo_region)
        problemRegions.push({
          label: "face mismatch",
          detail: "The person in the selfie does not match this photograph.",
          severity: "high",
          region: analysis.security_features.photo_region,
        });
    } else {
      addCheck({
        key: "face",
        label: "Selfie matches card photo",
        status: fm.confidence < 90 ? "warn" : "pass",
        detail: `Face match confidence ${Math.round(fm.confidence)}%.`,
        penalty: fm.confidence < 90 ? 3 : 0,
      });
    }
    if (!fm.selfie_looks_live) {
      addCheck({
        key: "liveness",
        label: "Selfie authenticity",
        status: "warn",
        detail: "The selfie looks like a photo of a screen or printed picture.",
        penalty: 10,
      });
      signals.push("selfie_not_live");
    }

    const penalty = checks.reduce((sum, c) => sum + c.penalty, 0);
    const score = Math.max(0, Math.min(100, Math.round((100 - penalty) * 10) / 10));
    const status: "ACCEPTED" | "REJECTED" = score >= ACCEPT_THRESHOLD ? "ACCEPTED" : "REJECTED";

    if (status === "REJECTED" && reasons.length === 0) {
      reasons.push(
        "Small inconsistencies across the checks kept the authenticity score below the 96% threshold.",
      );
    }

    const uniqueSignals = [...new Set(signals)];
    const dbMatch = { found: !!record, nameMatch, dobMatch, record };

    const { data: inserted } = await supabaseAdmin
      .from("verifications")
      .insert({
        doc_type: docType,
        extracted: analysis.details,
        checks,
        signals: uniqueSignals,
        problem_regions: problemRegions,
        reasons,
        db_match: dbMatch,
        score,
        status,
      })
      .select("id")
      .single();

    // Background learning ledger: remember every signal we have seen.
    for (const signal of uniqueSignals) {
      const { data: existing } = await supabaseAdmin
        .from("tamper_patterns")
        .select("id, occurrences, doc_types")
        .eq("signal", signal)
        .maybeSingle();
      if (existing) {
        const types = new Set([...((existing["doc_types"] as string[]) ?? []), docType]);
        await supabaseAdmin
          .from("tamper_patterns")
          .update({
            occurrences: (existing["occurrences"] as number) + 1,
            doc_types: [...types],
            last_seen: new Date().toISOString(),
          })
          .eq("id", existing["id"] as string);
      } else {
        await supabaseAdmin
          .from("tamper_patterns")
          .insert({ signal, doc_types: [docType], occurrences: 1 });
      }
    }

    return {
      id: (inserted?.["id"] as string | undefined) ?? null,
      docType,
      docLabel: DOC_LABELS[docType] ?? docType,
      score,
      status,
      details: analysis.details,
      checks,
      reasons,
      signals: uniqueSignals,
      problemRegions,
      dbMatch,
      quality: {
        blurScore: blur,
        enhanced: blur > 20,
        notes: analysis.image_quality.notes,
      },
      faceMatch: {
        comparable: fm.comparable,
        samePerson: fm.same_person,
        confidence: Math.round(fm.confidence),
        notes: fm.notes,
      },
    };
  });

export const submitReview = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => ReviewInput.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("verifications")
      .select("signals, status")
      .eq("id", data.verificationId)
      .single();

    await supabaseAdmin
      .from("verifications")
      .update({
        reviewer_verdict: data.verdict,
        reviewer_note: data.note ?? null,
        reviewed_at: new Date().toISOString(),
      })
      .eq("id", data.verificationId);

    const signals = ((row?.["signals"] as string[] | null) ?? []).filter(Boolean);
    const wasRejected = row?.["status"] === "REJECTED";
    // A rejection confirmed correct strengthens its signals; a wrong call weakens them.
    const confirmedFraud = wasRejected && data.verdict === "correct";

    for (const signal of signals) {
      const { data: pattern } = await supabaseAdmin
        .from("tamper_patterns")
        .select("id, confirmed_fraud, false_alarms")
        .eq("signal", signal)
        .maybeSingle();
      if (!pattern) continue;
      const confirmed = (pattern["confirmed_fraud"] as number) + (confirmedFraud ? 1 : 0);
      const falseAlarms = (pattern["false_alarms"] as number) + (confirmedFraud ? 0 : 1);
      const weight = Math.max(0.2, Math.min(2, (confirmed + 1) / (falseAlarms + 1)));
      await supabaseAdmin
        .from("tamper_patterns")
        .update({
          confirmed_fraud: confirmed,
          false_alarms: falseAlarms,
          weight: Math.round(weight * 100) / 100,
        })
        .eq("id", pattern["id"] as string);
    }

    return { ok: true };
  });
