export type DocType = "AADHAAR" | "PAN" | "DL" | "VOTER" | "OTHER" | "NOT_AN_ID";

export const DOC_LABELS: Record<string, string> = {
  AADHAAR: "Aadhaar Card",
  PAN: "PAN Card",
  DL: "Driving Licence",
  VOTER: "Voter ID (EPIC)",
  OTHER: "Unrecognised document",
  NOT_AN_ID: "Not an identity document",
};

export const ACCEPT_THRESHOLD = 96;

/** Verhoeff checksum — the algorithm UIDAI uses for the 12-digit Aadhaar number. */
const D = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
  [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
  [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
  [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
  [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
  [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
  [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
  [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
  [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
];
const P = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
  [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
  [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
  [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
  [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
  [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
  [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
  [7, 0, 4, 6, 9, 1, 3, 2, 5, 8],
];

export function isValidAadhaar(raw: string): boolean {
  const num = raw.replace(/\D/g, "");
  if (num.length !== 12 || num.startsWith("0") || num.startsWith("1")) return false;
  let c = 0;
  const digits = num.split("").reverse();
  for (let i = 0; i < digits.length; i++) {
    c = D[c]![P[(i + 1) % 8]![Number(digits[i])]!]!;
  }
  return c === 0;
}

export function isValidPan(raw: string): boolean {
  return /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(raw.replace(/\s/g, "").toUpperCase());
}

export function isValidVoterId(raw: string): boolean {
  return /^[A-Z]{3}[0-9]{7}$/.test(raw.replace(/\s/g, "").toUpperCase());
}

export function isValidDl(raw: string): boolean {
  const v = raw.replace(/[\s-]/g, "").toUpperCase();
  return /^[A-Z]{2}[0-9]{11,13}$/.test(v);
}

export function normaliseDocNumber(docType: string, raw: string | null): string {
  if (!raw) return "";
  const v = raw.trim().toUpperCase();
  if (docType === "AADHAAR") return v.replace(/\D/g, "");
  if (docType === "DL") return v.replace(/[\s-]/g, "");
  return v.replace(/\s/g, "");
}

export function checkDocNumberFormat(
  docType: string,
  docNumber: string,
): { applicable: boolean; valid: boolean; expected: string } {
  switch (docType) {
    case "AADHAAR":
      return {
        applicable: true,
        valid: isValidAadhaar(docNumber),
        expected: "12 digits with a valid UIDAI (Verhoeff) checksum",
      };
    case "PAN":
      return {
        applicable: true,
        valid: isValidPan(docNumber),
        expected: "5 letters, 4 digits, 1 letter (e.g. ABCPK1234D)",
      };
    case "VOTER":
      return {
        applicable: true,
        valid: isValidVoterId(docNumber),
        expected: "3 letters followed by 7 digits",
      };
    case "DL":
      return {
        applicable: true,
        valid: isValidDl(docNumber),
        expected: "State code + 11 to 13 digits (e.g. MH1220190004521)",
      };
    default:
      return { applicable: false, valid: false, expected: "" };
  }
}

export type Region = { x: number; y: number; w: number; h: number };

export type CheckResult = {
  key: string;
  label: string;
  status: "pass" | "warn" | "fail" | "skipped";
  detail: string;
  penalty: number;
};

export type ProblemRegion = {
  label: string;
  detail: string;
  severity: "low" | "medium" | "high";
  region: Region;
};

export type VerificationResult = {
  id: string | null;
  docType: string;
  docLabel: string;
  score: number;
  status: "ACCEPTED" | "REJECTED";
  details: Record<string, string | null>;
  checks: CheckResult[];
  reasons: string[];
  signals: string[];
  problemRegions: ProblemRegion[];
  dbMatch: {
    found: boolean;
    nameMatch: boolean;
    dobMatch: boolean;
    record: Record<string, string | null> | null;
  };
  quality: { blurScore: number; enhanced: boolean; notes: string };
  faceMatch: { comparable: boolean; samePerson: boolean; confidence: number; notes: string };
};
