import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import {
  ArrowRight,
  BadgeCheck,
  Fingerprint,
  Loader2,
  QrCode,
  ScanFace,
  ScanLine,
  Sparkles,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { AnnotatedCard, ChecksList, ScoreDial } from "@/components/ResultPanels";
import { UploadTile } from "@/components/UploadTile";
import { DOC_LABELS, type VerificationResult } from "@/lib/id-rules";
import { verifyIdentity } from "@/lib/verify.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sentinel ID — Verify Indian Identity Cards" },
      {
        name: "description",
        content:
          "Check an Aadhaar, PAN, Driving Licence or Voter ID against government records with tamper forensics, QR checks and selfie face matching.",
      },
      { property: "og:title", content: "Sentinel ID — Verify Indian Identity Cards" },
      {
        property: "og:description",
        content:
          "Upload an ID card and a selfie to get extracted details, an authenticity score and the exact reason for any rejection.",
      },
    ],
  }),
  component: Home,
});

const FIELD_LABELS: Array<[string, string]> = [
  ["full_name", "Name"],
  ["doc_number", "Document number"],
  ["dob", "Date of birth"],
  ["gender", "Gender"],
  ["father_name", "Father / guardian"],
  ["address", "Address"],
  ["issue_or_expiry_date", "Issue / expiry"],
  ["other_printed_text", "Other printed text"],
];

const STAGES = [
  "Cleaning and sharpening the images",
  "Reading the document and identifying its type",
  "Checking the number against government records",
  "Running tamper, QR and face-match forensics",
];

function Home() {
  const [idImage, setIdImage] = useState<string | null>(null);
  const [selfie, setSelfie] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState(0);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const runVerify = useServerFn(verifyIdentity);

  const run = async () => {
    if (!idImage || !selfie) {
      toast.error("Add both the ID card photo and a selfie.");
      return;
    }
    setBusy(true);
    setResult(null);
    setStage(0);
    const ticker = setInterval(() => setStage((s) => Math.min(STAGES.length - 1, s + 1)), 6000);
    try {
      const res = await runVerify({ data: { idImage, selfieImage: selfie } });
      setResult(res);
      toast[res.status === "ACCEPTED" ? "success" : "error"](
        res.status === "ACCEPTED" ? "Identity accepted" : "Identity rejected",
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Verification could not be completed.");
    } finally {
      clearInterval(ticker);
      setBusy(false);
    }
  };

  return (
    <main className="mx-auto w-full max-w-5xl px-4 pb-24 pt-8 sm:px-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="label-caps flex items-center gap-2">
            <Fingerprint className="size-4 text-primary" aria-hidden="true" />
            Sentinel ID · Document authenticity engine
          </p>
          <h1 className="mt-3 text-3xl font-semibold sm:text-4xl">
            Verify an Indian identity card
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            Aadhaar, PAN, Driving Licence and Voter ID. The card is read and cleaned, matched
            against the government registry, examined for tampering, and the selfie is compared
            with the photo on the card.
          </p>
        </div>
        <Link
          to="/review"
          className="inline-flex items-center gap-2 rounded-lg border border-border bg-secondary px-3 py-2 text-sm font-medium text-secondary-foreground transition-colors hover:bg-accent"
        >
          Review console <ArrowRight className="size-4" aria-hidden="true" />
        </Link>
      </header>

      <section className="mt-8 grid gap-4 sm:grid-cols-2">
        <UploadTile
          title="Identity card"
          hint="Front side, all four corners visible"
          value={idImage}
          onPick={setIdImage}
          capture="environment"
        />
        <UploadTile
          title="Selfie"
          hint="Face the camera in even light"
          value={selfie}
          onPick={setSelfie}
          capture="user"
        />
      </section>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={run}
          disabled={busy || !idImage || !selfie}
          className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {busy ? (
            <Loader2 className="size-4 animate-spin" aria-hidden="true" />
          ) : (
            <ScanLine className="size-4" aria-hidden="true" />
          )}
          {busy ? "Verifying…" : "Run verification"}
        </button>
        <span className="text-xs text-muted-foreground">
          Accepted only above 96% authenticity.
        </span>
      </div>

      {busy && (
        <section className="panel scan-sweep mt-6 p-5">
          <span className="scan-sweep-line" aria-hidden="true" />
          <p className="label-caps">Analysis in progress</p>
          <ul className="mt-3 space-y-2">
            {STAGES.map((s, i) => (
              <li
                key={s}
                className={`flex items-center gap-2 text-sm ${i <= stage ? "text-foreground" : "text-muted-foreground/60"}`}
              >
                {i < stage ? (
                  <BadgeCheck className="size-4 text-success" aria-hidden="true" />
                ) : i === stage ? (
                  <Loader2 className="size-4 animate-spin text-primary" aria-hidden="true" />
                ) : (
                  <span className="size-4" />
                )}
                {s}
              </li>
            ))}
          </ul>
        </section>
      )}

      {result && (
        <div className="mt-8 space-y-5">
          <section className="panel p-5">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="label-caps">Document detected</p>
                <h2 className="mt-1 text-2xl font-semibold">
                  {DOC_LABELS[result.docType] ?? result.docLabel}
                </h2>
              </div>
              <ScoreDial score={result.score} status={result.status} />
            </div>
          </section>

          {result.status === "REJECTED" && (
            <section className="panel border-destructive/50 p-5">
              <p className="label-caps text-destructive">Rejected — why</p>
              <ul className="mt-3 space-y-2">
                {result.reasons.map((r) => (
                  <li key={r} className="flex gap-2 text-sm">
                    <span className="mt-1 size-1.5 shrink-0 rounded-full bg-destructive" />
                    {r}
                  </li>
                ))}
              </ul>
              {result.problemRegions.length > 0 && idImage && (
                <div className="mt-5">
                  <p className="label-caps">Where the problem is</p>
                  <div className="mt-3 grid gap-4 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
                    <AnnotatedCard image={idImage} regions={result.problemRegions} />
                    <ol className="space-y-2 text-sm">
                      {result.problemRegions.map((r, i) => (
                        <li key={`${r.label}-${i}`} className="rounded-lg border border-border p-3">
                          <p className="font-medium capitalize">
                            {i + 1}. {r.label}
                            <span className="ml-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                              {r.severity}
                            </span>
                          </p>
                          <p className="mt-1 text-muted-foreground">{r.detail}</p>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              )}
            </section>
          )}

          <section className="grid gap-5 md:grid-cols-2">
            <div className="panel p-5">
              <p className="label-caps">Extracted details</p>
              <dl className="mt-3 space-y-2.5">
                {FIELD_LABELS.filter(([k]) => result.details[k]).map(([k, label]) => (
                  <div key={k} className="grid grid-cols-[8rem_minmax(0,1fr)] gap-3 text-sm">
                    <dt className="text-muted-foreground">{label}</dt>
                    <dd className="font-mono break-words">{result.details[k]}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-4 rounded-lg bg-background/50 p-3 text-xs text-muted-foreground">
                Image cleaned before reading · blur index {result.quality.blurScore}
                {result.quality.notes ? ` · ${result.quality.notes}` : ""}
              </div>
            </div>

            <div className="panel p-5">
              <p className="label-caps">Government registry</p>
              {result.dbMatch.found && result.dbMatch.record ? (
                <dl className="mt-3 space-y-2.5">
                  {(
                    [
                      ["full_name", "Name on file"],
                      ["dob", "Date of birth"],
                      ["gender", "Gender"],
                      ["father_name", "Father / guardian"],
                      ["address", "Address"],
                      ["issue_date", "Issued"],
                    ] as Array<[string, string]>
                  )
                    .filter(([k]) => result.dbMatch.record?.[k])
                    .map(([k, label]) => (
                      <div key={k} className="grid grid-cols-[8rem_minmax(0,1fr)] gap-3 text-sm">
                        <dt className="text-muted-foreground">{label}</dt>
                        <dd className="break-words">{result.dbMatch.record?.[k]}</dd>
                      </div>
                    ))}
                </dl>
              ) : (
                <p className="mt-3 text-sm text-muted-foreground">
                  No matching record was found in the government database.
                </p>
              )}
              <div className="mt-4 flex flex-wrap gap-2 text-xs">
                <span className="inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1">
                  <ScanFace className="size-3.5 text-primary" aria-hidden="true" /> Face match{" "}
                  {result.faceMatch.confidence}%
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1">
                  <QrCode className="size-3.5 text-primary" aria-hidden="true" />{" "}
                  {result.checks.find((c) => c.key === "qr")?.status ?? "n/a"}
                </span>
              </div>
            </div>
          </section>

          <section className="panel p-5">
            <p className="label-caps">All checks</p>
            <div className="mt-2">
              <ChecksList checks={result.checks} />
            </div>
          </section>

          {result.signals.length > 0 && (
            <section className="panel p-5">
              <p className="label-caps flex items-center gap-2">
                <Sparkles className="size-3.5 text-primary" aria-hidden="true" /> Signals sent to
                the learning model
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {result.signals.map((s) => (
                  <span
                    key={s}
                    className="rounded-full bg-secondary px-2.5 py-1 font-mono text-xs text-secondary-foreground"
                  >
                    {s}
                  </span>
                ))}
              </div>
              {result.id && (
                <p className="mt-3 text-xs text-muted-foreground">
                  Logged for review as {result.id.slice(0, 8)} —{" "}
                  <Link to="/review" className="text-primary underline">
                    confirm or correct this decision
                  </Link>{" "}
                  to teach the model.
                </p>
              )}
            </section>
          )}
        </div>
      )}
    </main>
  );
}
