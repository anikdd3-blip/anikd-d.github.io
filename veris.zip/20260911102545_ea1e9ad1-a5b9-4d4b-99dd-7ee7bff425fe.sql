CREATE TABLE public.gov_id_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  doc_type TEXT NOT NULL,
  doc_number TEXT NOT NULL,
  full_name TEXT NOT NULL,
  dob DATE,
  gender TEXT,
  address TEXT,
  father_name TEXT,
  issue_date DATE,
  photo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (doc_type, doc_number)
);
GRANT ALL ON public.gov_id_records TO service_role;
ALTER TABLE public.gov_id_records ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.verifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  doc_type TEXT NOT NULL DEFAULT 'UNKNOWN',
  extracted JSONB NOT NULL DEFAULT '{}'::jsonb,
  checks JSONB NOT NULL DEFAULT '[]'::jsonb,
  signals JSONB NOT NULL DEFAULT '[]'::jsonb,
  problem_regions JSONB NOT NULL DEFAULT '[]'::jsonb,
  reasons JSONB NOT NULL DEFAULT '[]'::jsonb,
  db_match JSONB NOT NULL DEFAULT '{}'::jsonb,
  score NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'REJECTED',
  reviewer_verdict TEXT,
  reviewer_note TEXT,
  reviewed_at TIMESTAMPTZ
);
GRANT SELECT, INSERT, UPDATE ON public.verifications TO anon, authenticated;
GRANT ALL ON public.verifications TO service_role;
ALTER TABLE public.verifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "verifications_read_all" ON public.verifications FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "verifications_insert_all" ON public.verifications FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "verifications_review_all" ON public.verifications FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.tamper_patterns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  signal TEXT NOT NULL UNIQUE,
  doc_types TEXT[] NOT NULL DEFAULT '{}',
  occurrences INTEGER NOT NULL DEFAULT 1,
  confirmed_fraud INTEGER NOT NULL DEFAULT 0,
  false_alarms INTEGER NOT NULL DEFAULT 0,
  weight NUMERIC NOT NULL DEFAULT 1,
  last_seen TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.tamper_patterns TO anon, authenticated;
GRANT ALL ON public.tamper_patterns TO service_role;
ALTER TABLE public.tamper_patterns ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tamper_patterns_read_all" ON public.tamper_patterns FOR SELECT TO anon, authenticated USING (true);

INSERT INTO public.gov_id_records (doc_type, doc_number, full_name, dob, gender, address, father_name, issue_date) VALUES
  ('AADHAAR', '923456789013', 'Rohit Kumar Sharma', '1994-03-12', 'MALE', 'H.No 44, Sector 15, Rohini, New Delhi - 110085', 'Mahesh Kumar Sharma', '2013-07-19'),
  ('AADHAAR', '934567890124', 'Ananya Iyer', '1998-11-02', 'FEMALE', '12/3 Besant Nagar, Chennai, Tamil Nadu - 600090', 'Ramesh Iyer', '2015-01-08'),
  ('AADHAAR', '945678901236', 'Imran Shaikh', '1989-06-25', 'MALE', 'Flat 302, Sai Residency, Andheri East, Mumbai - 400069', 'Yusuf Shaikh', '2012-09-30'),
  ('PAN', 'ABCPK1234D', 'Rohit Kumar Sharma', '1994-03-12', 'MALE', NULL, 'Mahesh Kumar Sharma', '2016-04-11'),
  ('PAN', 'AKJPI7765Q', 'Ananya Iyer', '1998-11-02', 'FEMALE', NULL, 'Ramesh Iyer', '2019-08-21'),
  ('DL', 'DL-0420110149646', 'Imran Shaikh', '1989-06-25', 'MALE', 'Flat 302, Sai Residency, Andheri East, Mumbai - 400069', 'Yusuf Shaikh', '2011-02-14'),
  ('DL', 'MH1220190004521', 'Priya Deshmukh', '1996-01-30', 'FEMALE', '7 Shivaji Nagar, Pune, Maharashtra - 411005', 'Sanjay Deshmukh', '2019-05-06'),
  ('VOTER', 'RXH2049871', 'Priya Deshmukh', '1996-01-30', 'FEMALE', '7 Shivaji Nagar, Pune, Maharashtra - 411005', 'Sanjay Deshmukh', '2018-03-02'),
  ('VOTER', 'ABC1234567', 'Suresh Nair', '1975-09-17', 'MALE', 'Thejus, Kowdiar, Thiruvananthapuram, Kerala - 695003', 'Balan Nair', '2009-11-25'),
  ('AADHAAR', '956789012347', 'Suresh Nair', '1975-09-17', 'MALE', 'Thejus, Kowdiar, Thiruvananthapuram, Kerala - 695003', 'Balan Nair', '2014-06-12');