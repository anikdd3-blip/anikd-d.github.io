import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Brain, Check, Loader2, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";
import { DOC_LABELS } from "@/lib/id-rules";
import { submitReview } from "@/lib/verify.functions";

export const Route = createFileRoute("/review")({
  head: () => ({
    meta: [
      { title: "Review console — Sentinel ID" },
      {
        name: "description",
        content:
          "Confirm or correct past identity verifications and watch the tampering signal ledger grow with each reviewed decision.",
      },
      { property: "og:title", content: "Review console — Sentinel ID" },
      {
        property: "og:description",
        content: "Reviewer verdicts on past ID checks train the tampering detection model.",
      },
    ],
  }),
  component: ReviewConsole,
});

type VerificationRow = {
  id: string;
  created_at: string;
  doc_type: string;
  score: number;
  status: string;
  reasons: string[];
  signals: string[];
  extracted: Record<string, string | null>;
  reviewer_verdict: string | null;
};

type PatternRow = {
  id: string;
  signal: string;
  occurrences: number;
  confirmed_fraud: number;
  false_alarms: number;
  weight: number;
  doc_types: string[];
};

function ReviewConsole() {
  const qc = useQueryClient();
  const review = useServerFn(submitReview);
  const [pending, setPending] = useState<string | null>(null);

  const verifications = useQuery({
    queryKey: ["verifications"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("verifications")
        .select(
          "id, created_at, doc_type, score, status, reasons, signals, extracted, reviewer_verdict",
        )
        .order("created_at", { ascending: false })
        .limit(30);
      if (error) throw error;
      return (data ?? []) as unknown as VerificationRow[];
    },
  });

  const patterns = useQuery({
    queryKey: ["tamper_patterns"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tamper_patterns")
        .select("id, signal, occurrences, confirmed_fraud, false_alarms, weight, doc_types")
        .order("occurrences", { ascending: false })
        .limit(40);
      if (error) throw error;
      return (data ?? []) as unknown as PatternRow[];
    },
  });

  const vote = async (id: string, verdict: "correct" | "incorrect") => {
    setPending(id);
    try {
      await review({ data: { verificationId: id, verdict } });
      toast.success("Thanks — the model has been updated.");
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["verifications"] }),
        qc.invalidateQueries({ queryKey: ["tamper_patterns"] }),
      ]);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save that verdict.");
    } finally {
      setPending(null);
    }
  };

  return (
    <main className="mx-auto w-full max-w-5xl px-4 pb-24 pt-8 sm:px-6">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="size-4" aria-hidden="true" /> Back to verification
      </Link>
      <h1 className="mt-4 text-3xl font-semibold">Review console</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Every check is logged with the signals behind it. Marking a decision right or wrong updates
        the weight of each signal, so repeat tampering techniques get caught faster.
      </p>

      <section className="panel mt-8 p-5">
        <p className="label-caps flex items-center gap-2">
          <Brain className="size-3.5 text-primary" aria-hidden="true" /> Learned tampering signals
        </p>
        {patterns.isLoading ? (
          <Loader2 className="mt-4 size-4 animate-spin text-muted-foreground" aria-hidden="true" />
        ) : patterns.data && patterns.data.length > 0 ? (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="label-caps">
                <tr className="text-left">
                  <th className="pb-2 pr-4 font-normal">Signal</th>
                  <th className="pb-2 pr-4 font-normal">Seen</th>
                  <th className="pb-2 pr-4 font-normal">Confirmed</th>
                  <th className="pb-2 pr-4 font-normal">False alarms</th>
                  <th className="pb-2 font-normal">Weight</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {patterns.data.map((p) => (
                  <tr key={p.id}>
                    <td className="py-2 pr-4 font-mono text-xs">{p.signal}</td>
                    <td className="py-2 pr-4">{p.occurrences}</td>
                    <td className="py-2 pr-4 text-success">{p.confirmed_fraud}</td>
                    <td className="py-2 pr-4 text-warning">{p.false_alarms}</td>
                    <td className="py-2 font-mono">{Number(p.weight).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="mt-3 text-sm text-muted-foreground">
            No signals recorded yet. Run a verification first.
          </p>
        )}
      </section>

      <section className="mt-6 space-y-4">
        <p className="label-caps">Recent verifications</p>
        {verifications.isLoading && (
          <Loader2 className="size-4 animate-spin text-muted-foreground" aria-hidden="true" />
        )}
        {verifications.data?.length === 0 && (
          <p className="text-sm text-muted-foreground">Nothing verified yet.</p>
        )}
        {verifications.data?.map((v) => (
          <article key={v.id} className="panel p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-sm font-semibold">
                  {DOC_LABELS[v.doc_type] ?? v.doc_type}
                  <span className="ml-2 font-mono text-xs text-muted-foreground">
                    {v.extracted?.["doc_number"] ?? "no number"}
                  </span>
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {new Date(v.created_at).toLocaleString()} ·{" "}
                  {v.extracted?.["full_name"] ?? "name unreadable"}
                </p>
              </div>
              <span
                className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                  v.status === "ACCEPTED"
                    ? "bg-success/15 text-success"
                    : "bg-destructive/15 text-destructive"
                }`}
              >
                {v.status} · {Number(v.score).toFixed(1)}%
              </span>
            </div>

            {v.reasons?.length > 0 && (
              <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
                {v.reasons.slice(0, 4).map((r, i) => (
                  <li key={i}>• {r}</li>
                ))}
              </ul>
            )}

            <div className="mt-4 flex flex-wrap items-center gap-2">
              {v.reviewer_verdict ? (
                <span className="rounded-md border border-border px-2.5 py-1.5 text-xs">
                  Reviewed: this decision was {v.reviewer_verdict}
                </span>
              ) : (
                <>
                  <button
                    type="button"
                    disabled={pending === v.id}
                    onClick={() => vote(v.id, "correct")}
                    className="inline-flex items-center gap-1.5 rounded-md bg-success/15 px-3 py-1.5 text-xs font-medium text-success transition-opacity hover:opacity-80 disabled:opacity-50"
                  >
                    <Check className="size-3.5" aria-hidden="true" /> Decision was right
                  </button>
                  <button
                    type="button"
                    disabled={pending === v.id}
                    onClick={() => vote(v.id, "incorrect")}
                    className="inline-flex items-center gap-1.5 rounded-md bg-destructive/15 px-3 py-1.5 text-xs font-medium text-destructive transition-opacity hover:opacity-80 disabled:opacity-50"
                  >
                    <X className="size-3.5" aria-hidden="true" /> Decision was wrong
                  </button>
                </>
              )}
              {v.signals?.slice(0, 5).map((s) => (
                <span
                  key={s}
                  className="rounded-full bg-secondary px-2 py-1 font-mono text-[10px] text-secondary-foreground"
                >
                  {s}
                </span>
              ))}
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}
